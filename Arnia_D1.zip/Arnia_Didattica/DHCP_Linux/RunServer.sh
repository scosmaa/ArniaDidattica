#!/bin/bash
./opendhcpd -v -i opendhcp.ini

